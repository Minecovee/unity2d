using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverManager : MonoBehaviour
{
    public void RestartGame()
    {
        // Load the main game scene (replace "MainGame" with the name of your actual game scene)
        SceneManager.LoadScene("SampleScene");
    }

    public void QuitGame()
    {
        // Quit the application
        Application.Quit();
    }
}
