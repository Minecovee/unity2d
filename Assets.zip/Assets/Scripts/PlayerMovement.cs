using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;
    public Animator animator;

    public float runSpeed = 20f;
    public float walkSpeed = 10f;

    public float landingLagDuration = 0.2f;
    private float _landingTimer;

    float horizontalMove = 0f;
    bool jump = false;
    bool crouch = false;
    bool isAttacking = false;

    // แก้ไข: เปลี่ยนสถานะ Block และเพิ่มสถานะ Parry
    private bool isBlocking = false;
    private bool _isParrying = false;
    
    // NEW: เพิ่มตัวแปรสำหรับ Parry
    public float parryWindow = 0.1f;
    private float _parryTimer;
    private bool _canParry;

    private int attackCombo = 0;
    private bool comboAllowed = true;
    public float attackPause1 = 0.1f;
    public float attackPause2 = 0.1f;

    private void Update()
    {
        // NEW: จัดการสถานะ Block และ Parry
        bool isBlockButtonDown = Input.GetButtonDown("Block");
        bool isBlockButtonUp = Input.GetButtonUp("Block");
        bool isBlockButtonPressed = Input.GetButton("Block");

        // ตรวจสอบสถานะการบล็อก
        if (isBlockButtonPressed)
        {
            isBlocking = true;
            animator.SetBool("IsBlocking", true);
        }
        else
        {
            isBlocking = false;
            animator.SetBool("IsBlocking", false);
        }

        // ตรวจสอบการ Parry (กดแล้วปล่อยอย่างรวดเร็ว)
        if (isBlockButtonDown)
        {
            _parryTimer = 0; // รีเซ็ตตัวนับเมื่อกดลง
        }

        if (isBlockButtonUp)
        {
            if (_parryTimer <= parryWindow)
            {
                _isParrying = true;
                StartCoroutine(ParryActiveTime());
            }
            else
            {
                _isParrying = false;
            }
        }
        _parryTimer += Time.deltaTime;

        // หากตัวละครกำลังบล็อก, Parry, หรือ Dash ให้หยุดรับ input อื่นๆ
        if (isBlocking || _isParrying || controller.isDashing)
        {
            horizontalMove = 0f;
            return;
        }

        if (_landingTimer > 0)
        {
            _landingTimer -= Time.deltaTime;
            horizontalMove = 0f;
        }
        else
        {
            float inputX = Input.GetAxisRaw("Horizontal");

            if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
            {
                horizontalMove = inputX * walkSpeed;
            }
            else
            {
                horizontalMove = inputX * runSpeed;
            }
        }

        animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

        if (Input.GetButtonDown("Jump"))
        {
            jump = true;
            animator.SetBool("IsJumping", true);
        }

        if (Input.GetButtonDown("Crouch"))
        {
            crouch = true;
        }
        else if (Input.GetButtonUp("Crouch"))
        {
            crouch = false;
        }

        if (Input.GetKeyDown(KeyCode.X) && controller.canDash && controller.m_Grounded)
        {
            animator.SetTrigger("Dash");
            StartCoroutine(controller.Dash());
        }

        if (Input.GetButtonDown("Attack") && !isAttacking && comboAllowed && !isBlocking)
        {
            Debug.Log("Attack button pressed, starting attack!");
            StartCoroutine(PerformAttack());
        }
    }
    
    // NEW: Coroutine สำหรับช่วงเวลาที่ Parry ทำงาน
    private IEnumerator ParryActiveTime()
    {
        animator.SetTrigger("Parry"); // คุณต้องเพิ่ม Trigger "Parry" ใน Animator Controller
        Debug.Log("Parry Active!");
        // เพิ่มโค้ดการจัดการผลลัพธ์ของ Parry เช่น ทำให้ศัตรูติดสถานะ Stun
        yield return new WaitForSeconds(parryWindow); 
        _isParrying = false;
    }

    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
        _landingTimer = landingLagDuration;
    }

    public void OnCrouching(bool isCrouching)
    {
        animator.SetBool("IsCrouching", isCrouching);
    }

    private void FixedUpdate()
    {
        controller.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump);
        jump = false;
    }

    private IEnumerator PerformAttack()
    {
        isAttacking = true;
        attackCombo = 0;

        animator.SetTrigger("Attack1");
        attackCombo++;
        yield return new WaitForSeconds(attackPause1);

        float timeSinceLastAttack = 0f;
        while (timeSinceLastAttack < attackPause2)
        {
            timeSinceLastAttack += Time.deltaTime;

            if (Input.GetButtonDown("Attack"))
            {
                animator.SetTrigger("Attack2");
                attackCombo++;
                yield return new WaitForSeconds(attackPause2);
                break;
            }

            yield return null;
        }

        if (attackCombo == 1)
        {
            isAttacking = false;
            animator.SetTrigger("Idle");
            yield break;
        }

        timeSinceLastAttack = 0f;
        while (timeSinceLastAttack < attackPause2)
        {
            timeSinceLastAttack += Time.deltaTime;

            if (Input.GetButtonDown("Attack"))
            {
                animator.SetTrigger("Attack3");
                attackCombo = 0;
                isAttacking = false;
                yield break;
            }

            yield return null;
        }

        isAttacking = false;
        animator.SetTrigger("Idle");
    }

    public void ResetAttack()
    {
        isAttacking = false;
        attackCombo = 0;
    }
}