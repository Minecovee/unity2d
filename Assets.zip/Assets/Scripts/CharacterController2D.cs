using UnityEngine;
using UnityEngine.Events;
using System.Collections;

public class CharacterController2D : MonoBehaviour
{
    // Dashing Variables
    [SerializeField] public bool canDash = true;
    public bool isDashing;
    [SerializeField] public float dashingPower = 20f;
    [SerializeField] public float dashingTime = 0.2f;
    [SerializeField] public float dashingCooldown = 1f;

    // New variable for the Trail Renderer
    [SerializeField] private TrailRenderer tr;

    // Movement variables
    [SerializeField] private float m_JumpForce = 300f; 
    [Range(0, 1)] [SerializeField] private float m_CrouchSpeed = .36f; 
    [Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f; 
    [SerializeField] private bool m_AirControl = false; 
    [SerializeField] private LayerMask m_WhatIsGround; 
    [SerializeField] private Transform m_GroundCheck; 
    [SerializeField] private Transform m_CeilingCheck; 
    [SerializeField] private Collider2D m_CrouchDisableCollider; 
    
    // New variables for dynamic jump
    [SerializeField] private float m_FallMultiplier = 2.5f;
    [SerializeField] private float m_LowJumpMultiplier = 2f;

    const float k_GroundedRadius = .15f; 
    public bool m_Grounded; 
    const float k_CeilingRadius = .2f; 
    private Rigidbody2D m_Rigidbody2D;
    private bool m_FacingRight = true; 
    private Vector3 m_Velocity = Vector3.zero;

    // Events
    [Header("Events")]
    [Space]
    public UnityEvent OnLandEvent;
    public class BoolEvent : UnityEvent<bool> { }
    public BoolEvent OnCrouchEvent;
    private bool m_wasCrouching = false;

    private void Awake()
    {
        m_Rigidbody2D = GetComponent<Rigidbody2D>();

        if (OnLandEvent == null)
            OnLandEvent = new UnityEvent();

        if (OnCrouchEvent == null)
            OnCrouchEvent = new BoolEvent();
    }

    private void FixedUpdate()
    {
        bool wasGrounded = m_Grounded;

        m_Grounded = false;
        Collider2D[] colliders = Physics2D.OverlapCircleAll(m_GroundCheck.position, k_GroundedRadius, m_WhatIsGround);
        for (int i = 0; i < colliders.Length; i++)
        {
            if (colliders[i].gameObject != gameObject)
            {
                m_Grounded = true;
                if (!wasGrounded)
                    OnLandEvent.Invoke();
            }
        }
        
        // Dynamic Gravity: เพิ่มแรงโน้มถ่วงเมื่อกำลังตกลง
        if (m_Rigidbody2D.velocity.y < 0)
        {
            m_Rigidbody2D.velocity += Vector2.up * Physics2D.gravity.y * (m_FallMultiplier - 1) * Time.fixedDeltaTime;
        } 
        // กระโดดสั้นลงถ้าผู้เล่นปล่อยปุ่มกระโดด
        else if (m_Rigidbody2D.velocity.y > 0 && !Input.GetButton("Jump"))
        {
            m_Rigidbody2D.velocity += Vector2.up * Physics2D.gravity.y * (m_LowJumpMultiplier - 1) * Time.fixedDeltaTime;
        }
    }

    public void Move(float move, bool crouch, bool jump)
    {
        if (isDashing)
        {
            return;
        }

        if (m_Grounded || m_AirControl)
        {
            if (crouch)
            {
                if (!m_wasCrouching)
                {
                    m_wasCrouching = true;
                    OnCrouchEvent.Invoke(true);
                }

                move *= m_CrouchSpeed;

                if (m_CrouchDisableCollider != null)
                    m_CrouchDisableCollider.enabled = false;
            }
            else
            {
                if (m_CrouchDisableCollider != null)
                    m_CrouchDisableCollider.enabled = true;

                if (m_wasCrouching)
                {
                    m_wasCrouching = false;
                    OnCrouchEvent.Invoke(false);
                }
            }

            Vector3 targetVelocity = new Vector2(move * 10f, m_Rigidbody2D.velocity.y);
            m_Rigidbody2D.velocity = Vector3.SmoothDamp(m_Rigidbody2D.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);

            if (move > 0 && !m_FacingRight)
            {
                Flip();
            }
            else if (move < 0 && m_FacingRight)
            {
                Flip();
            }
        }

        if (m_Grounded && jump)
        {
            m_Grounded = false;
            m_Rigidbody2D.AddForce(new Vector2(0f, m_JumpForce));
        }
    }

    private void Flip()
    {
        m_FacingRight = !m_FacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    public IEnumerator Dash()
    {
        isDashing = true;
        canDash = false;

        float originalGravity = m_Rigidbody2D.gravityScale;
        m_Rigidbody2D.gravityScale = 0f;
        
        // Enable the trail
        if (tr != null) tr.emitting = true;

        m_Rigidbody2D.velocity = new Vector2(transform.localScale.x * dashingPower, 0f);

        yield return new WaitForSeconds(dashingTime);

        // Disable the trail
        if (tr != null) tr.emitting = false;

        isDashing = false;
        m_Rigidbody2D.gravityScale = originalGravity;

        yield return new WaitForSeconds(dashingCooldown);
        canDash = true;
    }
}