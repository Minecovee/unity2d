using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // For loading the Game Over screen

public class EnemyAI : MonoBehaviour
{
    public Transform[] patrolPoints;    // The points the enemy patrols between
    public float patrolSpeed = 2f;      // Speed of patrol
    private int currentPatrolIndex;     // Index of current patrol point

    public Transform player;            // Reference to the player
    public float chaseRange = 5f;       // Distance within which enemy will start chasing the player
    public float attackRange = 1f;      // Distance within which enemy will attack the player
    public float chaseSpeed = 4f;       // Speed when chasing the player

    private bool isChasing = false;     // Is the enemy currently chasing the player?

    private Rigidbody2D rb;
    private Vector2 movement;

    private void Start()
    {
        currentPatrolIndex = 0;
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        // Check if the player is within the chase range
        if (distanceToPlayer < chaseRange)
        {
            // Start chasing the player
            isChasing = true;
        }
        else
        {
            // Stop chasing the player and return to patrol
            isChasing = false;
        }

        // Chase or Patrol behavior
        if (isChasing)
        {
            ChasePlayer();
        }
        else
        {
            Patrol();
        }
    }

    private void Patrol()
    {
        // Move towards the current patrol point
        Transform targetPatrolPoint = patrolPoints[currentPatrolIndex];
        movement = (targetPatrolPoint.position - transform.position).normalized;
        rb.MovePosition(rb.position + movement * patrolSpeed * Time.fixedDeltaTime);

        // Check if we reached the patrol point
        if (Vector2.Distance(transform.position, targetPatrolPoint.position) < 0.2f)
        {
            // Move to the next patrol point
            currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
        }
    }

    private void ChasePlayer()
    {
        // Move towards the player
        movement = (player.position - transform.position).normalized;
        rb.MovePosition(rb.position + movement * chaseSpeed * Time.fixedDeltaTime);

        // Check if we are close enough to attack
        if (Vector2.Distance(transform.position, player.position) < attackRange)
        {
            AttackPlayer();
        }
    }

    private void AttackPlayer()
    {
        // Load the Game Over screen when the enemy hits or attacks the player
        Debug.Log("Enemy attacks the player!");
        SceneManager.LoadScene("GameOver");
    }

    private void OnDrawGizmosSelected()
    {
        // Draw the chase and attack range in the editor for better visualization
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, chaseRange);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}
