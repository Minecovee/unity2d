using UnityEngine;
using UnityEngine.SceneManagement;  // Needed for reloading the scene

public class EndPoint : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        // Debug log to check if the player is touching the endpoint
        Debug.Log("Object entered trigger: " + other.name);

        // Check if the object that collided with the endpoint is the player
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player has reached the endpoint!");
            RestartGame();
        }
    }

    private void RestartGame()
    {
        // Reload the current scene to restart the game
        Debug.Log("Restarting the game...");
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
